
if($(window).width() > 767){
var t1Animation = gsap.timeline();
var t2Animation = gsap.timeline();
var t3Animation = gsap.timeline();
var t4Animation = gsap.timeline();
var t5Animation = gsap.timeline();

//CSSPlugin.defaultTransformPerspective=200;

function animateSecOneObjects(){
    
    t1Animation.from(".innovation-heading", {x:"-20",opacity:0,ease: "linear", duration:"1.3"}, "-=1")
               .from(".orange-circle-sm", {opacity:1, scale:"0.3",ease: "Bounce.easeOut", duration:"1.3"}, "-=1")
               .from("#inno_firstTriangle", {y:"-30vh",opacity:0,rotation:-150,ease: "linear", duration:"1"}, "-=1")
               .fromTo("#header_curve",{drawSVG:"100% 100%"}, {drawSVG:"0% 100%", duration:"1.5"}, "-=1")
               .from("#inno_rect_outer", {y:"-100vh",opacity:0,rotation:-150,ease: "linear", duration:"1.8"}, "-=2.2")
               .from(".inno_halfTriangle", {y:"-100vh",opacity:0,rotation:-180,ease: "linear", duration:"1.8"}, "-=1.9")
               .from("#inno_device_stand", {y:"-30vh",opacity:0,ease: Expo.easeOut, duration:"1"}, "-=1.2")
               .from("#inno_device", {y:"-30vh",opacity:0,ease: "linear", duration:"0.8"}, "-=1.2")
               .from(".inno_path, .inno_oval, .inno_rectangle", 1, {drawSVG:"0 0",ease:'sine.out',onComplete:func}, "-=0.8")
               .from("#inno_device_small_cir", {y:"-30vh",opacity:0,ease: "linear", duration:"0.8"}, "-=1.2")
               .from("#inno_blueCircle", {y:0,opacity:0,scale:0.7,ease: "linear",duration:"1"}, "-=1")
               .from(".inno-rect", {y:0,height:0,autoAlpha: 0,ease: "Expo.easeOut", rotation:"0", duration:"1.5"},"-=1")
               .from(".inno-frame circle, .inno-frame rect, .inno-frame polygon, .inno-frame path, .inno-frame line", 1, {drawSVG:"0 0",ease:'sine.out'}, "-=1")
               .from(".inno-crown circle, .inno-crown rect, .inno-crown polygon, .inno-crown path", 1, {drawSVG:"0 0",ease:'sine.out'}, "-=1")
              // .from(".inno-crown", {rotation: -350/150, transformOrigin:"center",repeat:-1,ease:Power0.easeNone}, "-=1");
              //.fromTo('.inno-crown' ,5, {rotationY:90,rotationZ:0, rotationX:0}, {rotationY:90,rotationZ:0,rotationX:0, transformOrigin:"50%, 50%"});

    function func(){
        jQuery(".landing_svg").addClass("finished");
    }
}

function animateSecTwoObjects(){

    t2Animation.set("#inno_blueCircle", {
        scale: 1,
      });
    t2Animation.to(".inno-rect", {motionPath:{
        path: ".inno-path",
        align: ".inno-path",
        alignOrigin: [0.5, 0.5],
        autoRotate:90,
       },
       ease: "none",
       duration:"1200",
       width:"38"
     })

    .to("#inno_blueCircle", {motionPath:{
        path: ".inno-circ-line",
        align: ".inno-circ-line",
        alignOrigin: [0.5, 1],  
       },
       ease: "none",
       duration:"1200",
       scale:0.6
    }, "-=1200")

    .from(".prod_svg", {opacity:0,ease: "linear", duration:"250"},"-=10")
    .from(".prod-bFrame rect", {drawSVG:"0 0",ease:'sine.out',duration:250},"-=10")
    .from(".prod-bFrame path, .prod-bFrame line", {drawSVG:"0 0",ease:'sine.out',duration:250},"-=9")
     
    // .to("#inno_rect_outer", {motionPath:{
    //     path: ".inno-rect-line",
    //     align: ".inno-rect-line",
    //     alignOrigin: [0.5, 1],
    //    },
    //    ease: "none",
    //    duration:"1200",

    //    opacity:0,
    //    width: 206,
    //    height:190,
    //    onComplete: function() {
    //     $("#inno_rect_outer").addClass("transparent-box");
    //   },
    //   onReverseComplete: function() {
    //     $("#inno_rect_outer").removeClass("transparent-box");
    //   },
    // }, "-=1100")

    

    // .to(".inno_halfTriangle", {motionPath:{
    //     path: ".inno-tri-line",
    //     align: ".inno-tri-line",
    //     //autoRotate: 90,
    //     alignOrigin: [0.5, 1]
    //    },
    //    ease: "none",
    //    duration:"1200",
    //    scale:0.75,
    // }, "-=1000")

    
    .from(".prod-rec rect", {drawSVG:"0 0",ease:'sine.out',duration:250},"-=9")
    .from(".prod-circle path", {drawSVG:"0 0",ease:'sine.out',duration:250},"-=9")
    .from(".prod_svg .svg_fill", {opacity:0,ease: "linear", duration:"250"},"-=9")
    .from(".prod-block path, .prod-block rect", {drawSVG:"0 0",ease:'sine.out',duration:150},"-=9")
    .from(".prod-left-block rect", {drawSVG:"0 0",ease:'sine.out',duration:150},"-=9")
    .from(".prod-girl path, .prod-girl line, .prod-girl rect, .prod-girl polygon", {drawSVG:"0 0",ease:'sine.out',duration:100},"-=9")
    .from(".prod-smallCir circle", {drawSVG:"0 0",ease:'sine.out',duration:100},"-=9")
    .fromTo(".prod-cap", {x:0}, {x:0, duration:100, ease: Expo.easeOut},"-=9")
    .from(".prod-board rect, .prod-board line, .prod-board polygon, .prod-board path", {drawSVG:"0 0",ease:'sine.out',duration:100},"-=9")
    .fromTo(".board_btn", {x:0, scale:1}, {x:10, scale:0.8, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=9")
    .fromTo(".board_btn", {x:10, scale:1}, {y:0, scale:0.8, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=8")
    .fromTo(".board_btn", {y:10, scale:0.8}, {x:10, scale:1, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=8")
    .fromTo(".board_btn", {x:10, scale:0.8}, {x:20, scale:1, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=8")
    .fromTo(".board_btn", {x:20, scale:0.8}, {y:10, scale:1, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=8")
    .fromTo(".board_btn", {y:10, scale:0.8}, {x:0, scale:1, duration:120, ease: Elastic.easeOut.config(1, 0.3)},"-=8")
    // .fromTo(".board_btn", {x:0, scale:0.8}, {y:0, scale:1, duration:100, ease: SteppedEase.config(12)},"-=8")
    // .fromTo(".board_btn", {x:0, scale:0.8}, {x:20, scale:1, duration:100, ease: SteppedEase.config(12)},"-=8")
    // .fromTo(".board_btn", {x:0, scale:0.8}, {y:10, scale:1, duration:100, ease: SteppedEase.config(12)},"-=8")
    // .fromTo(".board_btn", {x:0, scale:0.8}, {x:0, scale:1, duration:100, ease: SteppedEase.config(12)},"-=8")
    .from(".prod-crown polygon, .prod-crown path", {drawSVG:"0 0",ease:'sine.out',duration:100},"-=10")

    if(($(window).width() == 768 && $(window).height() == 1024) || ($(window).width() == 1024 && $(window).height() == 1366)){
        ScrollTrigger.create({
            trigger: ".sec-product",
            animation: t2Animation,
            start: "20px 60%",
            end: "-=300",
            scrub:2,
            toggleActions: "play pause resume none",
        });
    }
    else {
        ScrollTrigger.create({
            trigger: ".sec-product",
            animation: t2Animation,
            start: "20px 80%",
            end: "-=300",
            scrub:2,
            toggleActions: "play pause resume none",
        });
    }
}

function animateSecThreeObjects(){
    t3Animation.from(".orangeLine-holder path",3, {drawSVG:"0 0",ease:'sine.out'}) 
               .fromTo("#dot1", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1,autoAlpha: 1.375}, "-=1.4")
               .fromTo("#dot2", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=1.5")
               .fromTo("#dot3", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=1.6")
               .fromTo("#dot4", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=1.7")
               .fromTo("#dot5", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=1.8")
               .from(".lineBox-holder path",3, {drawSVG:"0 0",ease:'sine.out'},"-=2") 
               .fromTo("#dot6", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=1.9")
               .fromTo("#dot7", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2")
               .fromTo("#dot8", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.1")
               .fromTo("#dot9", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.2")
               .fromTo("#dot10", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.3")
               .fromTo("#dot11", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.4")
               .fromTo("#dot12", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.5")
               .fromTo("#dot13", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.6")
               .fromTo("#dot14", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.7")
               .fromTo("#dot15", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=2.8")
               .fromTo("#dot16", {autoAlpha: 0,scale:0}, {duration: 0.3, scale:1, autoAlpha: 1.375},"-=3")
    
    ScrollTrigger.create({
        trigger: ".sec-innovator",
        animation: t3Animation,
        start: "top top",
        end: "bottom bottom",
        scrub:2,
        toggleActions: "play none none none",
        onUpdate: function() {
            jQuery(".innovator_dots").parent(".innovator_svg").addClass("finished");
          }
    });
}

function animateSecFourObjects(){
    t4Animation.set(".falling-ball", {y:"-100vh"});
    t4Animation.set(".falling-rect", {y:"-100vh"});
    
    if(($(window).width() == "1024" && $(window).height() == "1366") || ($(window).width() == "768" && $(window).height() == "1024") || ($(window).width() == "1024" && $(window).height() == "768")){
        t4Animation.to(".falling-ball",0.5, {y:"-75", ease:Back.easeOut.config(1.6)})
               .fromTo(".report-content", {autoAlpha: 0, x:100}, {duration: 0.3, autoAlpha: 1.375, x: 0},"-=0.5")
               //.from(".report-block polyline, .report-block circle",3, {drawSVG:"0 0",ease:'sine.out'}, "-=0.5")
               .to(".falling-rect",0.5, {y:"-70", ease:Back.easeOut.config(1.6)},"-=0.5");
    }
    else {
        t4Animation.from(".report_svg", {opacity:0,ease: "linear", duration:"0.5"})
        .fromTo(".report-content", {autoAlpha: 0, x:100}, {duration: 1.3, autoAlpha: 1.375, x: 0},"-=0.5")
        .from(".report-block polyline, .report-block circle",3, {drawSVG:"0 0",ease:'sine.out'}, "-=0.5")
        .fromTo(".falling-ball", {y:"-100vh"}, {duration: 2.5, y:0,ease: Expo.easeOut},"-=2")
        .fromTo(".falling-rect", {y:"-90vh"}, {duration: 2.5, y:0, ease: Expo.easeOut},"-=2.1")
       // .to(".falling-ball",1, {y:"-75"},"-=0.5")
               
               
              // .to(".falling-rect",1, {y:"-70" },"-=0.5");

    }

    ScrollTrigger.create({
        trigger: ".sec-report",
        start: "-40% 20px",
        end: "-=70",
        animation: t4Animation,
        scrub:3,
       // toggleActions: "play none complete none",
    });
}

function animateSecFiveObjects(){
    //t5Animation.fromTo(".aboutSvg_1 svg .about-block", {transformOrigin:"center center",scale:0.5}, {scale:1.3});
    t5Animation.fromTo(".aboutSvg_1 svg .about-img", {transformOrigin:"center center",scale:0.2,autoAlpha:0}, {scale:1.15, autoAlpha:1.375})
               .fromTo(".aboutSvg_1 svg .about-block1", {transformOrigin:"center center",scale:1}, {scale:1})
               .fromTo(".aboutSvg_1 svg .about-block2", {transformOrigin:"center center",scale:0.2}, {scale:1}, "-=1")
               .fromTo(".about-box-1", {autoAlpha: 0, x:60}, {duration: 1, autoAlpha: 1.375, x: 0}, "-=1.2")
               .fromTo(".aboutSvg_1 svg .about-block3", {transformOrigin:"center center",scale:0.2}, {scale:1}, "-=1")
               .fromTo(".aboutSvg_1 svg .about-block4", {transformOrigin:"center center",scale:0.2}, {scale:1}, "-=1")
               
               .fromTo(".aboutSvg_2 svg .platform-block", {transformOrigin:"center center",scale:0.2,autoAlpha:0}, {scale:1, autoAlpha:1}, "-=1.1")
               .fromTo(".aboutSvg_2 svg .platform-box", {transformOrigin:"center center",scale:0.2}, {scale:1}, "-=1")
               .fromTo(".aboutSvg_2 svg path", {transformOrigin:"center center",opacity:0}, {opacity:1.375}, "-=1")
               .fromTo(".about-box-2", {autoAlpha: 0, x:60}, {duration: 1, autoAlpha: 1.375, x: 0}, "-=1")

               //.from(".aboutSvg_3 svg .lock-path", {drawSVG:"0 0",ease:'sine.out',duration:100,autoAlpha:1.375}, "-=0.9")
               .fromTo(".aboutSvg_3 svg .lock", {transformOrigin:"center center",scale:0.2}, {scale:1}, "-=0.9")
               .fromTo(".aboutSvg_3 svg .lock-path", {drawSVG:"0"}, {drawSVG:"100%",ease:'sine.out'}, "-=0.8")
               .fromTo(".aboutSvg_3 svg path", {transformOrigin:"center center",autoAlpha:0}, { autoAlpha:1.375}, "-=0.8")
               .fromTo(".about-box-3", {autoAlpha: 0, x:60}, {duration: 1, autoAlpha: 2, x: 0}, "-=0.9")
            

    ScrollTrigger.create({
        trigger: ".sec-about",
        animation: t5Animation,
        scrub:3,
        //toggleActions: "play none complete none",
    });
}

function setSvgPathDirection() {
    var viewportWidth = $(window).width();
    var viewportHeight = $(window).height();

  // alert(viewportHeight);
    // if(viewportWidth <= "1799" && viewportWidth >= "1600") {
    //     jQuery(".moving-rect .inno-path").attr("d","m30,45c0,437.5-248.5,657.5-1000,635.5");
    //     //jQuery(".inno-tri-holder .inno-tri-line").attr("d","M17.8,50.7l-551.2,755.2");
    //     jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-215.9,500.6c-118.6,107.6-133.5,348.9-135.7,386.9");
    // }
    // else if(viewportWidth <= "1599" && viewportWidth > "1440") {
    //     jQuery(".moving-rect .inno-path").attr("d","M35,45c0,437.5-248.5,657.5-1070,635.5");
    //     //jQuery(".inno-tri-holder .inno-tri-line").attr("d","M18.8,50.7l-450.3,754.2");
    //     jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-140.9,500.6c-118.6,107.6-133.5,348.9-135.7,386.9");
    // }

    if(viewportWidth == "1440") {
        jQuery(".moving-rect .inno-path").attr("d","M35,60c0,437.5-248.5,730.5-1070,700.5");
        //jQuery(".inno-tri-holder .inno-tri-line").attr("d","M18.8,50.7l-450.3,712.2");
        //jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-140.9,468.6c-118.6,107.6-133.5,348.9-135.7,386.9");
    }

    else if(viewportWidth <= "1439" && viewportWidth >= "1367") {
        jQuery(".moving-rect .inno-path").attr("d","M35,45c0,437.5-248.5,657.5-1070,635.5");
       // jQuery(".inno-tri-holder .inno-tri-line").attr("d","M18.8,50.7l-540.3,754.2");
       // jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-215.9,500.6c-118.6,107.6-133.5,100.9-135.7,386.9");
    }
    
    else if((viewportWidth == "1366" && viewportHeight == "1024")) {
        
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,437.5-248.5,725.5-1200,710.5");
       // jQuery(".inno-tri-holder .inno-tri-line").attr("d","M18.8,50.7l-450.3,940.2");
       // jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-140.9,630.6c-128.6,107.6-133.5,100.9-135.7,386.9");
    }

    else if((viewportWidth == "1366" && viewportHeight >= "640") || (viewportWidth == "1366" && viewportHeight <= "690")) {
        
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,437.5-248.5,790.5-1100,770.5");
       // jQuery(".inno-tri-holder .inno-tri-line").attr("d","M18.8,50.7l-450.3,940.2");
       // jQuery(".inno-circ-line").attr("d","M35.4,157.7C41,241.5-25,343.6-140.9,630.6c-128.6,107.6-133.5,100.9-135.7,386.9");
    }

    else if((viewportWidth == "1280" && viewportHeight >= "880") || (viewportWidth == "1280" && viewportHeight <= "940")) {
        
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,437.5-248.5,720.5-1060,710.5");
    }

    else if(viewportWidth == "1024" && viewportHeight == "1366") {
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,437.5-248.5,740.5-880,730.5");
      
    }

    else if(viewportWidth == "1024" && viewportHeight == "768") {
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,450.5-248.5,690.5-880,690.5");
      
    }

    else if(viewportWidth == "768" && viewportHeight == "1024") {
        jQuery(".moving-rect .inno-path").attr("d","M35,55c0,437.5-248.5,1130.5-1450,1140.5");
      
    }
    
}

function initLandingVideo() {
    let allVideoDivs = gsap.utils.toArray('.video-container');
    allVideoDivs.forEach(function(videoDiv, i) {
        
        let videoElem = videoDiv.querySelector('div')
        ScrollTrigger.create({
            trigger: videoElem,
            start: 'top 80%',
            end: 'top 20%',
            onEnter: function(){
                _wq.push({
                    id: "ch40o1qjh0", onReady: function (video) {
                        video.play();
                    }
                });
            },
            onEnterBack: function() {
                _wq.push({
                    id: "ch40o1qjh0", onReady: function (video) {
                        video.play();
                    }
                });
            },
            onLeave: function() {
                _wq.push({
                    id: "ch40o1qjh0", onReady: function (video) {
                        video.pause();
                    }
                });
            },
            onLeaveBack: function() {
                _wq.push({
                    id: "ch40o1qjh0", onReady: function (video) {
                        video.pause();
                    }
                });
            }
        });
    });      
}

$(document).ready(function() {
    if($(window).width() > 767){
        animateSecOneObjects();
        animateSecTwoObjects();
        animateSecThreeObjects();
        animateSecFourObjects();
        animateSecFiveObjects();
        //setSvgPathDirection();
        initLandingVideo();
    }
});


$(window).resize(function() {
    if($(window).width() > 767){
        //setSvgPathDirection();
    }
});
}