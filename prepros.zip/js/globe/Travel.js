(function() {

	Travel = function() {};

	var p = Travel.prototype;

	p.getBranch = function(id) {
		var branch;
		switch(id) {
			default:
				branch = new FlyToDestination(id);
				break;
		}
		return branch;
	};

	p.hide = function() {
		this.root.globe.deselectCountries();
	};

}());
