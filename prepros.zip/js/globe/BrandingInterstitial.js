(function() {

	BrandingInterstitial = function() {};

	var p = BrandingInterstitial.prototype;

	// OnLoad Globe Settings
	p.show = function() {
		this.root.highlighCountries();
		this.renderBind = this.render.bind(this);
		tsunami.clock.addEventListener("tick", this.renderBind);
		this.root.orbitalCamera.radius = 1.3;
		this.root.globe.latitude = 40;
		this.root.globe.position.x = 0;
		this.root.globe.position.y = 0;
		this.root.globe.position.z = 0;
		this.render();
	};

	p.render = function() {
		// OnLoad Globe Speed
		this.root.globe.longitude -= 0.1;

		// OnLoad Globe Renderer
		this.root.render();
	};

	p.hide = function() {
		tsunami.clock.removeEventListener("tick", this.renderBind);
	};

}());
