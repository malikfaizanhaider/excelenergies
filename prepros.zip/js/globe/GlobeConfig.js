GlobeConfig = {
	sphere:{
		color:'#F9F9F9',
		opacity: 1
	},
	dot: {
		normal:{
			color:"#898989",
			opacity: 1
		},
		selected:{
			color:"#F09929",
			opacity: 1
		}
	},
	ambientLightColor: '#F9F9F9',
	light: {
		color:'#F9F9F9',
		intensity: 0
	},
	glow: {
		color:'#F9F9F9',
		scale: 0
	}
};
