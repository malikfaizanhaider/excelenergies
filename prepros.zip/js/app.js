function initShowContactUsWrapper() {
    jQuery("#contactUs_btn").on("click", function(){
        //jQuery(".landing-contact-form").removeClass("slideDown").removeClass("slideUp");
        jQuery(this).css('visibility', 'hidden');
        //jQuery(".contact-wrapper .landing-contact-form").fadeIn().addClass("slideDown");
        jQuery(".contact-wrapper .landing-contact-form").slideDown(1500).css("visibility", "visible");
            // jQuery(".contact-wrapper-inner").css( {'padding': '0' } )
            // .animate( { 'padding': '7.5em 0 7.5em' }, 1500 );
            jQuery(".contact-wrapper-inner .form-group").css( {'position': 'relative', 'left':'50px','opacity': '0' } )
            .animate( { 'left':'0', 'opacity':'1' }, 1000 );
        
        jQuery("#landing-footer-contact").hide();
        jQuery("#landing-footer-bottom").show();
    });
}

function initHideContactUsWrapper() {
    jQuery("#submitForm_btn").on("click", function(){
        jQuery(this).parents(".sec-contact").removeClass("form-open");
        jQuery(".landing-contact-form").fadeOut();
        jQuery(".landing-contact-form").removeClass("slideDown").removeClass("slideUp");
        jQuery(".landing-contact-form").removeClass("slideDown").addClass("slideUp");
        setTimeout(function(){ 
            jQuery("#contactUs_btn").css('visibility', 'visible');
         }, 200);
        
       
    });
}

function initMoveToContactForm() {
    jQuery("#moveToContactForm").on("click", function(e){
        e.preventDefault()

        $('html, body').animate(
          {
            scrollTop: $($(this).attr('href')).offset().top,
          },
          500,
          'linear'
        )
    });
}

jQuery(document).ready(function(){
    initShowContactUsWrapper();
   // initHideContactUsWrapper();
  // initMoveToContactForm();
   
});

// $.fn.isOnScreen = function(){
    
//     var win = $(window);
    
//     var viewport = {
//         top : win.scrollTop(),
//         left : win.scrollLeft()
//     };
//     viewport.right = viewport.left + win.width();
//     viewport.bottom = viewport.top + win.height();
    
//     var bounds = this.offset();
//     bounds.right = bounds.left + this.outerWidth();
//     bounds.bottom = bounds.top + this.outerHeight();
    
//     return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));
    
// };
// $(window).scroll(function() {
//     if ($('.video-container').isOnScreen() == true) {
//         console.log("video play");
//     }
    
// });


