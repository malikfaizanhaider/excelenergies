 //helper functions, it turned out chrome doesn't support Math.sgn() 
 if($(window).width() > 767){

 function signum(x) {
    return (x < 0) ? -1 : 1;
}
function absolute(x) {
    return (x < 0) ? -x : x;
}

function drawPath(svg, path, startX, startY, endX, endY) {
    // get the path's stroke width (if one wanted to be  really precize, one could use half the stroke size)
    var stroke =  parseFloat(path.attr("stroke-width"));
    // check if the svg is big enough to draw the path, if not, set heigh/width
    if (svg.attr("height") <  endY)                 svg.attr("height", endY);
    if (svg.attr("width" ) < (startX + stroke) )    svg.attr("width", (startX + stroke));
    if (svg.attr("width" ) < (endX   + stroke) )    svg.attr("width", (endX   + stroke));
    
    var svgContainerClass = svg.attr("class");

    var deltaX = (endX - startX) * 0.15;
    // var deltaY = (endY - startY) * 0.15;
    var deltaY = (endY - startY) * 0.15;

    if(svgContainerClass == "moving_triangle" || svgContainerClass == "moving_square"){
        var deltaY = (endY - startY) * 0.763;
    }

    if(svgContainerClass == "moving_circle"){
        var deltaY = (endY - startY) * 0.53;
    }

    if($(window).width() <= 1799 && svgContainerClass == "moving_triangle"){
        var deltaY = (endY - startY) * 0.732;
    }

    if($(window).width() <= 1440 && svgContainerClass == "moving_triangle"){
        var deltaY = (endY - startY) * 0.596;
    }

    if($(window).width() <= 1280 && svgContainerClass == "moving_triangle"){
        var deltaY = (endY - startY) * 0.545;
    }

    if($(window).width() == 1024 && $(window).height() == 1366){
        var deltaY = (endY - startY) * 0.482;
    }

    if($(window).width() == 768 && $(window).height() == 1024){
        var deltaY = (endY - startY) * 0.41;
    }

    if($(window).width() == 1024 && $(window).height() == 768){
        var deltaY = (endY - startY) * 0.558;
    }

    // for further calculations which ever is the shortest distance
    var delta  =  deltaY < absolute(deltaX) ? deltaY : absolute(deltaX);

    // set sweep-flag (counter/clock-wise)
    // if start element is closer to the left edge,
    // draw the first arc counter-clockwise, and the second one clock-wise
    var arc1 = 0; var arc2 = 1;
    if (startX > endX) {
        arc1 = 1;
        arc2 = 0;
    }

    // draw tha pipe-like path
    // 1. move a bit down, 2. arch,  3. move a bit to the right, 4.arch, 5. move down to the end 

    // path.attr("d",  "M"  + startX + " " + startY +
    // " V" + (startY + delta) +
    // " A" + delta + " " +  delta + " 0 0 " + arc1 + " " + (startX + delta*signum(deltaX)) + " " + (startY + 2*delta) +
    // " H" + (endX - delta*signum(deltaX)) + 
    // " A" + delta + " " +  delta + " 0 0 " + arc2 + " " + endX + " " + (startY + 3*delta) +
    // " V" + endY );

    if(svgContainerClass == "moving_triangle" || svgContainerClass == "moving_square") {
        path.attr("d",  "M"  + startX + " " + startY +
        "L" + (startX + deltaY*signum(deltaX)) + " "  + absolute(endY) );
    }

    if(svgContainerClass == "moving_circle") {
        path.attr("d",  "M"  + startX + " " + startY +
        //"V" + startX  + " "  + startY +
        //"Q" + startX + " " + startY * 8 + " " + endX + " " + endY 
         "C" + startX + " " + startY *5 + " " + endX + " " + deltaY * 2 + " "+ endX + " " + endY 
       // "C" + startX * 2 + " " + startY *4 + " " + endX + " " + deltaX * 0 + " "+ endX + " " + endY 
        //"T" + endX+ " " + endY
        // "s" + startX + " " + startY + " " + endX + " " + endY
        );
    }

    if(svgContainerClass == "orange_rect") {
        path.attr("d",  "M"  + startX + " " + startY +
        //"V" + startX * 3  + " "  + startY +
        //"Q" + startX + " " + startY * 8 + " " + endX + " " + endY 
        "C" + startX + " " + (startY + 500)  + " " + deltaX + " " + endY + " "+ endX + " " + endY 
        //"T" + endX+ " " + endY
        // "s" + startX + " " + startY + " " + endX + " " + endY
        );
    }
}

function connectElements(svgContainer, svg, path, startElem, endElem) {
    var svgContainer = svgContainer;
    var containerClass = svgContainer.attr("class");

    // if first element is lower than the second, swap!
    if(startElem.offset().top > endElem.offset().top){
        var temp = startElem;
        startElem = endElem;
        endElem = temp;
    }

    // get (top, left) corner coordinates of the svg container  
     
    if(containerClass == "inno-square-holder"){
        var svgTop  = svgContainer.offset().top + 12;
        var svgLeft = svgContainer.offset().left + 5;
    }

    else if (containerClass == "moving-rect"){
        var svgTop  = svgContainer.offset().top + 100 ;
        var svgLeft = svgContainer.offset().left ;
    }

    else if (containerClass == "inno-circ-holder"){
        var svgTop  = svgContainer.offset().top - 94;
        var svgLeft = svgContainer.offset().left - 60;
    }

    else {
        var svgTop  = svgContainer.offset().top;
        var svgLeft = svgContainer.offset().left;
    }

    if($(window).width() <= 1799){
        if(containerClass == "inno-square-holder"){
            var svgTop  = svgContainer.offset().top - 2;
            var svgLeft = svgContainer.offset().left - 2;
        }
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top + 150 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() <= 1600){
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top + 50 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() <= 1440){
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top + 130 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() == 1024 && $(window).height() == 1366){
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top - 25 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() == 768 && $(window).height() == 1024){
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top - 25 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() == 1024 && $(window).height() == 768){
        if (containerClass == "moving-rect"){
            var svgTop  = svgContainer.offset().top + 35 ;
            var svgLeft = svgContainer.offset().left ;
        }
    }

    if($(window).width() <= 1230){
        if(containerClass == "inno-square-holder"){
            var svgTop  = svgContainer.offset().top - 20;
            var svgLeft = svgContainer.offset().left - 10;
        }

        if(containerClass == "inno-tri-holder"){
            var svgTop  = svgContainer.offset().top - 16;
            var svgLeft = svgContainer.offset().left - 6 ;
        }
    }

    if($(window).width() == 768){
        if(containerClass == "inno-square-holder"){
            var svgTop  = svgContainer.offset().top - 30;
            var svgLeft = svgContainer.offset().left - 20;
        }

        if(containerClass == "inno-tri-holder"){
            var svgTop  = svgContainer.offset().top - 22;
            var svgLeft = svgContainer.offset().left - 12 ;
        }
    }

    // get (top, left) coordinates for the two elements
    var startCoord = startElem.offset();
    var endCoord   = endElem.offset();

    // calculate path's start (x,y)  coords
    // we want the x coordinate to visually result in the element's mid point
    var startX = startCoord.left + 0.5*startElem.outerWidth() - svgLeft;    // x = left offset + 0.5*width - svg's left offset
    var startY = startCoord.top  + startElem.outerHeight() - svgTop;        // y = top offset + height - svg's top offset

        // calculate path's end (x,y) coords
    if(containerClass == "inno-tri-holder"){
        var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft;
        var endY = endCoord.top  - svgTop + 5;
    }

    else if(containerClass == "inno-circ-holder"){
        var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 33;
        var endY = endCoord.top  - svgTop - 40;
    }

    else {
        var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 100 ;
        var endY = endCoord.top  - svgTop + 85 ;
    }

    if($(window).width() <= 1799){
        if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 100 ;
            var endY = endCoord.top  - svgTop + 188 ;
        }
    }

    if($(window).width() <= 1600){
        if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 100 ;
            var endY = endCoord.top  - svgTop + 35 ;
        }
    }

    if($(window).width() <= 1440){
        if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 50 ;
            var endY = endCoord.top  - svgTop + 175 ;
        }
    }

    if($(window).width() <= 1230){
        if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 130 ;
            var endY = endCoord.top  - svgTop + 195 ;
        }
        else if(containerClass == "inno-circ-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 125;
            var endY = endCoord.top  - svgTop + 155;
        }
        else if(containerClass == "inno-tri-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 210;
            var endY = endCoord.top  - svgTop + 302;
        }
    }

    if($(window).width() == 1024 && $(window).height() == 1366){
       
        if(containerClass == "inno-circ-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 170;
            var endY = endCoord.top  - svgTop + 325;
        }
        else if(containerClass == "inno-tri-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft;
            var endY = endCoord.top  - svgTop + 470;
        }
        else if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 140 ;
            var endY = endCoord.top  - svgTop + 45 ;
        }
    }

    if($(window).width() == 1024 && $(window).height() == 768){
       
        if(containerClass == "inno-circ-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 183;
            var endY = endCoord.top  - svgTop + 305;
        }
        else if(containerClass == "inno-tri-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 280;
            var endY = endCoord.top  - svgTop + 438;
        }
        else if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 60 ;
            var endY = endCoord.top  - svgTop + 70 ;
        }
    }

    if($(window).width() == 768 && $(window).height() == 1024){
        if(containerClass == "inno-circ-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 140;
            var endY = endCoord.top  - svgTop + 335;
        }
        else if(containerClass == "inno-tri-holder"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 190;
            var endY = endCoord.top  - svgTop + 437;
        }
        else if(containerClass == "moving-rect"){
            var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft - 680;
            var endY = endCoord.top  - svgTop + 655;
        }
    }
    

    // call function for drawing the path
    drawPath(svg, path, startX, startY, endX, endY);

}

function connectAll() {
    // connect all the paths you want!
   // connectElements($(".inno-tri-holder"), $(".inno-tri-holder svg"), $(".inno-tri-line"), $(".inno-tri-holder"),  $(".prod_connect"));
    //connectElements($(".inno-square-holder"), $(".inno-square-holder svg"), $(".inno-rect-line"), $(".inno-square-holder"),  $(".prod_rect_connect"));
    connectElements($(".moving-rect"), $(".moving-rect svg"), $(".inno-path"), $(".moving-rect"),  $(".prod_line_connect"));
    connectElements($(".inno-circ-holder"), $(".inno-circ-holder svg"), $(".inno-circ-line"), $(".inno_circle"),  $(".prod-circ-connect"));
}

$(document).ready(function() {
    // reset svg each time 
   // $(".inno-tri-holder svg").attr("height", "0");
    //$(".inno-tri-holder svg").attr("width", "0");
    connectAll();
});

$(window).resize(function () {
    // reset svg each time 
   $(".inno-tri-holder svg").attr("width", "34");
   // $(".inno-tri-holder svg").attr("width", "0");
    connectAll();
});
 }